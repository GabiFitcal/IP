﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterBuilder : MonoBehaviour {
	public GameObject head;
	public GameObject middle;
	public GameObject leg;
	// Use this for initialization
	void Start () {
		Instantiate (head, new Vector2 (3.5f, -0.3f), Quaternion.identity);
		Instantiate (middle, new Vector2 (3.5f, -1.84f), Quaternion.identity);
		Instantiate (leg, new Vector2 (3.5f, -2.75f), Quaternion.identity);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
