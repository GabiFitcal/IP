﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class level1Manager : MonoBehaviour {

	public GameObject liniePrefab;
	List<GameObject> linii = new List<GameObject> ();
	public GameObject euro;
	public CanvasGroup finishPanel;

	int step;
	// Use this for initialization
	void Start () {
		step = 0;
	}
	
	// Update is called once per frame
	void Update () {
	}

	public void playGame(){
		foreach(GameObject linie in linii)
		{
			linie.GetComponent<Rigidbody2D> ().bodyType = RigidbodyType2D.Dynamic;
		}
		euro.GetComponent<Rigidbody2D> ().bodyType = RigidbodyType2D.Dynamic;
	}

	public void deseneazaLinie(){
		GameObject linie = Instantiate(liniePrefab,new Vector2 (0, 0), Quaternion.identity);
		linii.Add (linie);
		step++;
	}

//	public void removeLastObjectInLines(){
//		linii.RemoveAt (linii.Count - 1);
//	}

	public void restartGame(){
		GameObject obj = GameObject.Find ("Euro");
		obj.transform.position = new Vector3 (-5.77f, 2.88f, 0f);
		obj.GetComponent<Rigidbody2D> ().bodyType = RigidbodyType2D.Static;
		foreach(GameObject linie in linii)
		{
			Destroy (linie);
		}
		linii = new List<GameObject> ();
	}

	public void levelCompleted(){
		finishPanel.alpha = 1;
		finishPanel.blocksRaycasts = true;
		foreach(GameObject linie in linii)
		{
			linie.SetActive (false);
		}
		linii = new List<GameObject> ();
		GameObject.Find ("Euro").SetActive (false);
	}

	public void selectLevel(){
		Singleton.SelectLevel ();
	}

	public void nextLevel(){
		Application.LoadLevel("Level2");
	}


	public void Undo(){
		if (step > 0) {
			linii [step - 1].SetActive (false);
			step--;
		}
	}

	public void Redo(){
		if (step <linii.Count) {
			linii [step].SetActive (true);
			step++;
		}
	}

}
