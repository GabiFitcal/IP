﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoneyScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Rigidbody2D rb = gameObject.AddComponent<Rigidbody2D>();
		rb.bodyType = RigidbodyType2D.Static;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
