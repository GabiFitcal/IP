﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(LineRenderer))]
public class PolygonPainter : MonoBehaviour {

	public delegate void PolygonPainterDelegate(PolygonPainterEventArgs e);

	/// <summary>
	/// Gets fired when a polygon paint is finished
	/// </summary>
	public event PolygonPainterDelegate PolygonPainted;

	/// <summary>
	/// the "detail" of the line.
	/// the distance between single line parts.
	/// </summary>
	private float dotDistance = 0.1f;


	/// <summary>
	/// true if the player is painting at the moment.
	/// </summary>
	private bool isPainting;

	/// <summary>
	/// while painting the position of the last drawn point of the line.
	/// </summary>
	private Vector2 lastPointPosition;

	private Vector3 startPos;	
	private Vector3 endPos;


	/// <summary>
	/// The line renderer.
	/// </summary>
	private LineRenderer lineRenderer;

	void OnEnable()
	{		
		isPainting = false;
		lineRenderer = GetComponent<LineRenderer>();

	}
	void Start(){
		if(!isPainting)
		{
			InitPaintMode();
		}
	}

	void OnMouseOver(){
		if(Input.GetMouseButtonDown(0)){
			Destroy (gameObject);
		}
	}

	/// <summary>
	/// Update the painter
	/// </summary>
	void Update () {
		if (isPainting) {
			if (Input.GetMouseButtonUp (0)) {			
				ClosePolygon ();
			} else  {
				Paint();
			}
		}
	}



	/// <summary>
	/// Initialize the paint mode
	/// </summary>
	void InitPaintMode ()
	{
		lineRenderer.SetVertexCount(1);
		startPos = Get2DMousePosition ();
		lineRenderer.SetPosition(0, startPos);
		isPainting = true;
	}

	/// <summary>
	/// Add new points to the line
	/// </summary>
	void Paint ()
	{
		if(!isPainting)
		{
			return;
		}

		if (Vector2.Distance(Get2DMousePosition(), lastPointPosition) >= dotDistance) 
		{
			lineRenderer.SetVertexCount(2);
			lineRenderer.SetPosition(1, Get2DMousePosition());
			lastPointPosition = Get2DMousePosition();
		}
	}

	/// <summary>
	/// Closes the polygon.
	/// </summary>
	void ClosePolygon()
	{
		endPos = Get2DMousePosition ();
		lineRenderer.SetPosition(1, endPos);
		isPainting = false;
		if (endPos == startPos) {
			gameObject.SetActive (false);
		} else {
			Rigidbody2D rb = gameObject.AddComponent<Rigidbody2D>();
			rb.bodyType = RigidbodyType2D.Static;
			addColliderToLine ();
		}
	}
	private void addColliderToLine()
	{	
		GameObject obj = new GameObject ("Collider");
		BoxCollider2D col = obj.AddComponent<BoxCollider2D> ();
		col.transform.parent = transform; // Collider is added as child object of line
		float lineLength = Vector3.Distance (startPos, endPos); // length of line
		col.size = new Vector3 (lineLength, 0.5f, 0f); // size of collider is set where X is length of line, Y is width of line, Z will be set as per requirement
		Vector3 midPoint = (startPos + endPos)/2;
		col.transform.position = midPoint; // setting position of collider object
		// Following lines calculate the angle between startPos and endPos
		float angle = (Mathf.Abs (startPos.y - endPos.y) / Mathf.Abs (startPos.x - endPos.x));
		if((startPos.y<endPos.y && startPos.x>endPos.x) || (endPos.y<startPos.y && endPos.x>startPos.x))
		{
			angle*=-1;
		}
		angle = Mathf.Rad2Deg * Mathf.Atan (angle);
		col.transform.Rotate (0, 0, angle);

	}

	/// <summary>
	/// Get the 2D position of the mouse or touch
	/// </summary>
	/// <returns>The D mouse position.</returns>
	Vector3 Get2DMousePosition()
	{
		var result = Camera.main.ScreenToWorldPoint(Input.mousePosition);
		result.z = 0f;
		return result;
	}
}
