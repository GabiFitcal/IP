﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacaterScript : MonoBehaviour {
	private level1Manager manager;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnCollisionEnter2D(Collision2D coll) 
	{
		if(coll.gameObject.name == "Euro")
		{
			manager = GameObject.Find ("GameManager").GetComponent<level1Manager> ();
			manager.levelCompleted ();
		}
	}
}
