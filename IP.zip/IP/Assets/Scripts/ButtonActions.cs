﻿using UnityEngine;
using System.Collections;

public class ButtonActions : MonoBehaviour {



	// Use this for initialization
	void Start () {
		Singleton.Instance ();
	}
	
	// Update is called once per frame
	void Update () {
	
	}


	public void startLevel1(){
		Application.LoadLevel("Level1");
	}

	public void startLevel2(){
		Application.LoadLevel("Level2");
	}

	public void startLevel3(){
		Application.LoadLevel("Level3");
	}
}
