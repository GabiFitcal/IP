﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class characterLevel2 : MonoBehaviour {
	public Level2Manager manager;
	bool euro1 =false;
	bool euro2 =false;
	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {

	}

	void OnCollisionEnter2D(Collision2D coll) 
	{
		if(coll.gameObject.name == "Euro")
		{
			euro1 = true;
			GameObject.Find ("Euro").SetActive (false);
			checkIfIsLevelComplete ();
		}
		if(coll.gameObject.name == "Euro2")
		{
			euro2 = true;
			GameObject.Find ("Euro2").SetActive (false);
			checkIfIsLevelComplete ();
		}
	}
	void checkIfIsLevelComplete(){
		if (euro1 && euro2) {
			manager.levelCompleted ();
		}

	}
}
