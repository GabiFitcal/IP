﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level2Manager : MonoBehaviour {

	public GameObject liniePrefab;
	List<GameObject> linii = new List<GameObject> ();
	public GameObject euro;
	public GameObject euro2;
	public CanvasGroup finishPanel;

	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
	}

	public void playGame(){
		foreach(GameObject linie in linii)
		{
			linie.GetComponent<Rigidbody2D> ().bodyType = RigidbodyType2D.Dynamic;
		}
		euro.GetComponent<Rigidbody2D> ().bodyType = RigidbodyType2D.Dynamic;
		euro2.GetComponent<Rigidbody2D> ().bodyType = RigidbodyType2D.Dynamic;
	}

	public void deseneazaLinie(){
		GameObject linie = Instantiate(liniePrefab,new Vector2 (0, 0), Quaternion.identity);
		linii.Add (linie);
	}

	public void removeLastObjectInLines(){
		linii.RemoveAt (linii.Count - 1);
	}

	public void restartGame(){
		euro.SetActive (true);
		euro2.SetActive (true);
		euro.transform.position = new Vector3 (-4.16f, 3.15f, 0f);
		euro.GetComponent<Rigidbody2D> ().bodyType = RigidbodyType2D.Static;
		euro2.transform.position = new Vector3 (4.57f, 3.21f, 0f);
		euro2.GetComponent<Rigidbody2D> ().bodyType = RigidbodyType2D.Static;
		foreach(GameObject linie in linii)
		{
			Destroy (linie);
		}
		linii = new List<GameObject> ();
	}

	public void levelCompleted(){
		finishPanel.alpha = 1;
		finishPanel.blocksRaycasts = true;
		foreach(GameObject linie in linii)
		{
			linie.SetActive (false);
		}
		linii = new List<GameObject> ();
		euro.SetActive (false);
		euro2.SetActive (false);
	}


	public void selectLevel(){
		Singleton.SelectLevel ();
	}

	public void nextLevel(){
		Application.LoadLevel("Level3");
	}
}
