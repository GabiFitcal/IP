﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace FlyweightPattern
{
	//Class that includes lists with position of body parts
	public class Money
	{
		public List<Vector3> moneyPostion;
	}
}