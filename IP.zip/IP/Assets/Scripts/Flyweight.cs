﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

//Flyweight design pattern main class
namespace FlyweightPattern
{



	public class Flyweight : MonoBehaviour
	{

		public int number = 200;
		public GameObject moneyObject;
		public Vector2 minPosition = new Vector2(-10,-2);
		public Vector2 maxPosition = new Vector2 (10, -5);


		void Start()
		{
			for (int i = 0; i < number; i++)
			{
				//Make visual representations of the soldiers
				float x = Random.Range(minPosition.x, maxPosition.x);
				float y = Random.Range(minPosition.y, maxPosition.y);
				Instantiate(moneyObject,new Vector3(x,y,0),Quaternion.identity);

			}
		}


		//Generate a list with body part positions
		List<Vector3> GetBodyPartPositions()
		{
			//Create a new list
			List<Vector3> bodyPartPositions = new List<Vector3>();

			//Add body part positions to the list
			for (int i = 0; i < 1000; i++)
			{
				bodyPartPositions.Add(new Vector3());
			}

			return bodyPartPositions;
		}
	}
}